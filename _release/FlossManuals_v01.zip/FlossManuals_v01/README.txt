Ad Hoc Distribution ZIP for FLOSSMANUALS App.
========================================


   Drag .mobileprovision cert into iTunes
      Tester only has to do this once, unless cert is updated.
   Double click FlossManuals.ipa
      iTunes will install the Ad Hoc app to Applications
   Sync your mobile device
      iTunes will install the Ad Hoc provisioned release

--
Saturday 31st July 2010
Andy Nicholson
